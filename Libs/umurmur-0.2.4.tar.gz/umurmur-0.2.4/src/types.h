#ifndef TYPES_H_90878954
#define TYPES_H_90878954

typedef enum {
	false,
	true
} bool_t;

#endif

